
package value

trait Value {
  ;
}
